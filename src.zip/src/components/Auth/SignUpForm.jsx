import React from 'react';
import { useNavigate } from 'react-router-dom';
import PasswordInput from './PasswordInput';
import SocialSignIn from './SocialSignIn';
import './Auth.css';

const SignUpForm = () => {
  const navigate = useNavigate();

  const handleRegister = (e) => {
    e.preventDefault();
    // Normally validate form or call an API here
    navigate('/home');
  };

  return (
    <div className="auth-container">
      <img src="/assets/logo.png" alt="Optscale" className="auth-logo" />
      <form className="auth-form" onSubmit={handleRegister}>
        <input type="email" placeholder="Business email (login) *" required />
        <input type="text" placeholder="Full name *" required />
        <PasswordInput placeholder="Password" />
        <PasswordInput placeholder="Confirm password" />

        <p className="note">No credit card required. 30 seconds to sign up.</p>

        <button type="submit" className="auth-button">REGISTER</button>
        <p className="policy-text">
          By registering you agree to Hystax’s <a href="/">privacy policy</a>.
        </p>
        <p className="switch-auth">Already have an account? <a href="/signin">Sign in</a></p>
      </form>
      <SocialSignIn />
    </div>
  );
};

export default SignUpForm;
