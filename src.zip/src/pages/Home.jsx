import React from 'react';

const Home = () => {
  return (
    <div style={{ textAlign: 'center', marginTop: '40px' }}>
      <h1>Welcome to Optscale!</h1>
      <p>You’ve successfully registered.</p>
    </div>
  );
};

export default Home;
