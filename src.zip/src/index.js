import React from 'react';
import ReactDOM from 'react-dom/client'; // if using React 18+
import App from './App';
import './index.css'; // optional if you're using custom styles or Tailwind

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
