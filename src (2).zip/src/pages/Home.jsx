import React, { useState } from 'react';
import {
  FaRegStar,
  FaBuilding,
  FaBookOpen,
  FaQuestionCircle,
  FaGraduationCap,
  FaUserCircle
} from 'react-icons/fa';
import './Home.css';

const Home = () => {
  const [showAlert, setShowAlert] = useState(true);
  const [starCount] = useState(1473);
  const [organization] = useState('Sunflower Inc');

  return (
    <div className="home-container font-sans text-sm">
      {/* Alert bar */}
      {showAlert && (
        <div className="top-alert">
          <span>
            Please consider giving OptScale a{' '}
            <button className="star-button">
              <FaRegStar /> Star <span className="font-bold">{starCount.toLocaleString()}</span>
            </button>{' '}
            on GitHub. It’s 100% open-source and helps boost visibility and development. Thanks!
          </span>
          <button onClick={() => setShowAlert(false)} className="dismiss-button">
            ✖
          </button>
        </div>
      )}

      {/* Header */}
      <header className="header">
        {/* Left section */}
        <div className="header-left">
          <div className="logo-container">
            <div className="logo-spinner"></div>
            <span className="logo-text">optscale</span>
            <span className="demo-tag">DEMO</span>
          </div>
          <span className="demo-mode">You are in a live demo mode</span>
          <button className="register-button">REGISTER</button>
        </div>

        {/* Right section */}
        <div className="header-right">
          <div className="org-selector">
            <FaBuilding className="text-blue-800" />
            <span>{organization}</span>
            <span>▾</span>
          </div>
          <FaBookOpen className="header-icon" />
          <FaQuestionCircle className="header-icon" />
          <FaGraduationCap className="header-icon" />
          <FaUserCircle className="header-icon" />
        </div>
      </header>

      {/* Welcome message */}
      <section className="welcome-section">
        <h1 className="welcome-title">Welcome to Optscale!</h1>
        <p className="welcome-subtitle">You’ve successfully registered.</p>
      </section>
    </div>
  );
};

export default Home;
